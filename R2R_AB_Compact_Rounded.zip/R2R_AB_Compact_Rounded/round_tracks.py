"""Replace eligible KiCad two-segment corners with tangent copper arcs."""
from collections import defaultdict
from pathlib import Path
import json
import math
import sys

import pcbnew as p

def xy(point):
    return point.x,point.y

def unit(v):
    length=math.hypot(*v)
    return tuple(a/length for a in v),length

def vector(position):
    return p.VECTOR2I(*(round(v) for v in position))

def route(source, target, excluded):
    board=p.LoadBoard(str(source))
    junctions=defaultdict(list)
    vias=[]
    for track in board.GetTracks():
        if isinstance(track,p.PCB_VIA):
            vias.append(track)
        elif type(track)==p.PCB_TRACK:
            for end,other in ((track.GetStart(),track.GetEnd()),(track.GetEnd(),track.GetStart())):
                junctions[track.GetLayer(),xy(end)].append((track,xy(other)))
    pads=[(pad,pad.GetBoundingBox()) for f in board.GetFootprints() for pad in f.Pads()]
    planned=[]
    for (layer,corner),branches in sorted(junctions.items()):
        key=f"{layer}:{corner[0]}:{corner[1]}"
        if excluded.get(key,1)==0 or len(branches)!=2:
            continue
        (left,a),(right,b)=branches
        if left.GetNetCode()!=right.GetNetCode() or left.GetNetCode()==0 or left.GetWidth()!=right.GetWidth():
            continue
        c=vector(corner)
        if any(pad.IsOnLayer(layer) and box.Contains(c) for pad,box in pads):
            continue
        if any(v.IsOnLayer(layer) and math.dist(xy(v.GetPosition()),corner)<=v.GetWidth(layer)/2 for v in vias):
            continue
        u,la=unit(tuple(a[i]-corner[i] for i in range(2)))
        v,lb=unit(tuple(b[i]-corner[i] for i in range(2)))
        angle=math.acos(max(-1,min(1,sum(u[i]*v[i] for i in range(2)))))
        if not math.radians(35)<angle<math.radians(175):
            continue
        cut=min(p.FromMM(.55),la*.22,lb*.22)*excluded.get(key,1)
        radius=cut*math.tan(angle/2)
        if cut<p.FromMM(.055) or radius<p.FromMM(.05):
            continue
        bisector,_=unit(tuple(u[i]+v[i] for i in range(2)))
        through=cut/math.cos(angle/2)-radius
        coords=[vector([corner[i]+direction[i]*distance for i in range(2)])
                for direction,distance in ((u,cut),(bisector,through),(v,cut))]
        if len({xy(c) for c in coords})!=3:
            continue
        planned.append((key,corner,left,right,coords,radius))
    index={}
    arcs={}
    for key,corner,left,right,(start,mid,end),radius in planned:
        arc=p.PCB_ARC(board)
        arc.SetStart(start);arc.SetMid(mid);arc.SetEnd(end)
        arc.SetLayer(left.GetLayer());arc.SetWidth(left.GetWidth());arc.SetNet(left.GetNet())
        board.Add(arc)
        uuids=[arc.m_Uuid.AsString()]
        arcs[uuids[0]]=key
        for track,newpoint in ((left,start),(right,end)):
            if xy(track.GetStart())==corner: track.SetStart(newpoint)
            elif xy(track.GetEnd())==corner: track.SetEnd(newpoint)
            else: raise RuntimeError("Track endpoint already modified")
            uuids.append(track.m_Uuid.AsString())
        for uuid in uuids: index.setdefault(uuid,[]).append(key)
    p.SaveBoard(str(target),board)
    return {"count":len(planned),"radius_mm":[round(p.ToMM(row[-1]),4) for row in planned],"items":index,"arc_items":arcs}

source,target,exclusions,index=map(Path,sys.argv[1:])
data=route(source,target,json.loads(exclusions.read_text()))
index.write_text(json.dumps(data))
print(f"{target.stem}: {data['count']} arcs")
