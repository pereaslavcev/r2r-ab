"""Import combined KiCad netlists with deliberate placement around the reused blocks."""
import csv
from pathlib import Path
import re
from xml.etree import ElementTree as E
import pcbnew as p

out = Path(__file__).resolve().parent
source = out.parent / "R2R_AB_System_Rev2/boards"
for name, offsets, boundary in [
    ("dac_analog", [("dac_core",0,0,0),("analog",1000,0,0)],(25,25,178,115)),
    ("digital_input",[("input",0,0,0),("xmos_adapter",1000,66,54),("spdif_receiver",2000,65,0)],(27,24,179,121)),
]:
    spec={}
    for folder,num,dx,dy in offsets:
        with (source / folder / "placement.csv").open() as f:
            for ref,x,y in csv.reader(f):
                letter,digits=re.fullmatch(r"([A-Z]+)(\d+)",ref).groups()
                spec[letter+str(int(digits)+num)]=(float(x)+dx,float(y)+dy,0)
    if name=="dac_analog":
        spec.update(U1=(94,68,0),U2=(94,94,180),J5=(120,28,90),J6=(148,31,90))
        cap_left=[(83,52),(83,56),(92,54),(99,55),(107,55),(84,65),(84,70),(85,77),(94,77),(101,78)]
        cap_right=[(91,85),(98,85),(105,85),(112,84),(84,94),(86,101),(92,104),(99,105),(106,106),(113,106)]
        for offset,values in [(10,cap_left),(20,cap_right)]:
            for i,(x,y) in enumerate(values,1): spec[f"C{offset+i}"]=(x,y,0)
    board=p.BOARD()
    board.SetCopperLayerCount(4)
    def xy(x,y): return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
    x1,y1,x2,y2=boundary
    corners=[(x1,y1),(x2,y1),(x2,y2),(x1,y2)]
    for start,end in zip(corners,corners[1:]+corners[:1]):
        shape=p.PCB_SHAPE()
        shape.SetShape(p.SHAPE_T_SEGMENT)
        shape.SetStart(xy(*start));shape.SetEnd(xy(*end))
        shape.SetLayer(p.Edge_Cuts);shape.SetWidth(p.FromMM(.05))
        board.Add(shape)
    circuit=E.parse(out/f"{name}.xml")
    parts={}
    for item in circuit.findall("./components/comp"):
        ref=item.get("ref")
        group,fp=item.findtext("footprint").split(":")
        footprint=p.FootprintLoad(f"/usr/share/kicad/footprints/{group}.pretty",fp)
        assert footprint
        footprint.SetReference(ref)
        footprint.SetValue(item.findtext("value"))
        footprint.SetFPID(p.LIB_ID(group,fp))
        footprint.SetPath(p.KIID_PATH("/"+item.findtext("tstamps").split()[0]))
        x,y,angle=spec[ref]
        footprint.SetPosition(xy(x,y));footprint.SetOrientationDegrees(angle)
        footprint.Value().SetVisible(False)
        footprint.Reference().SetTextSize(xy(.85,.85))
        board.Add(footprint)
        parts[ref]=footprint
    for source_net in circuit.findall("./nets/net"):
        net=p.NETINFO_ITEM(board,source_net.get("name"));board.Add(net)
        for item in source_net.findall("node"):
            pads=[pad for pad in parts[item.get("ref")].Pads() if pad.GetNumber()==item.get("pin")]
            assert pads,item.attrib
            for pad in pads: pad.SetNet(net)
    p.SaveBoard(str(out/f"{name}.kicad_pcb"),board)
    assert p.ExportSpecctraDSN(board,str(out/f"{name}.dsn"))
    print(name,len(parts),"footprints")
