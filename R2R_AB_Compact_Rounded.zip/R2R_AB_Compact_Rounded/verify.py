import csv,re
from collections import defaultdict
from pathlib import Path
from xml.etree import ElementTree as E
root=Path(__file__).resolve().parent
for name,ids in [('dac_analog',{'DAC':0,'ANA':1000}),('digital_input',{'IN':0,'USB':1000,'SPD':2000})]:
    groups=defaultdict(set)
    for net,board,ref,pin in list(csv.reader((root/f'{name}_nets.csv').open()))[1:]:
        letters,number=re.fullmatch(r'([A-Za-z]+)(\d+)',ref).groups()
        groups[net].add((letters+str(int(number)+ids[board]),pin))
    expected={frozenset(pins) for pins in groups.values()}
    obj=E.parse(root/f'{name}.xml')
    actual={frozenset((n.get('ref'),n.get('pin')) for n in net.findall('node'))
            for net in obj.findall('./nets/net')}
    diff=(expected-actual,actual-expected)
    assert not any(diff),(name,diff)
    print(f'{name}: {len(expected)} pin groups exactly match the approved merge map')
