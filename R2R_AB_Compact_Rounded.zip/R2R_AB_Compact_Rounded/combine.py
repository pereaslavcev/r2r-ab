"""Combine generated flat source sheets and merge nets from verified interface maps."""
import csv
import re
import sys
from pathlib import Path
from uuid import uuid4
from xml.etree import ElementTree as ET

sources = dict(DAC="dac_core/DAC_Core", ANA="analog/Analog", IN="input/Input",
               USB="xmos_adapter/XMOS", SPD="spdif_receiver/Receiver")
boards, maps, target = map(Path,sys.argv[1:])
tokens = re.compile(r'"(?:[^"\\]|\\.)*"|[()]')
coord = re.compile(r'\((at|xy) (-?[\d.]+) (-?[\d.]+)')
def children(s):
    depth = 0
    for m in tokens.finditer(s):
        t=m[0]
        if t=="(":
            depth+=1
            if depth==2: start=m.start()
        elif t==")":
            if depth==2: yield s[start:m.end()]
            depth-=1
def point(x,y):
    return round(float(x),4),round(float(y),4)
def anchors(block):
    return [point(m[2],m[3]) for m in coord.finditer(block)]

def build(name,active):
    blocks, pins, aliases, parents = {}, {}, {}, {}
    for b in active:
        xml=ET.parse(boards/(sources[b]+".xml"))
        source=(boards/(sources[b]+".kicad_sch")).read_text()
        blocks[b]=list(children(source))
        for net in xml.findall("./nets/net"):
            label=net.get("name").lstrip("/")
            parents[b,label]=(b,label)
            for n in net.findall("node"):
                pins[b,n.get("ref"),n.get("pin")]=(b,label)
    def find(x):
        while parents[x]!=x:
            x=parents[x]
        return x
    for row in csv.DictReader((maps/(name+"_links.csv")).open()):
        left=pins[row["board_a"],row["connector_a"],row["pin_a"]]
        right=pins[row["board_b"],row["connector_b"],row["pin_b"]]
        parents[find(right)]=find(left)
    for key in parents:
        b, net=find(key)
        aliases[key]=net if b==active[0] else f"{b}_{net}"
    removed={
        "DAC":{"J1","J2","J3","J4"}, "ANA":{"J1","J2","J3","J4","J7"},
        "IN":{"J1","J2"}, "USB":{"J2"}, "SPD":{"J4"},
    }
    root=str(uuid4())
    names={}
    libraries={}
    table={}
    final=[]
    flag_nets=set()
    for index,b in enumerate(active):
        folder=(boards/sources[b]).parent
        for tablefile in folder.glob("sym-lib-table"):
            for entry in children(tablefile.read_text()):
                if entry.startswith("(lib "):
                    lib=re.search(r'\(name "([^"]+)"\)',entry)[1]
                    libfile=re.search(r'\$\{KIPRJMOD\}/([^"]+)',entry)[1]
                    renamed=f"{b}_{lib}"
                    newfile=f"{b}_{libfile}"
                    names[b,lib]=renamed
                    (target/newfile).write_bytes((folder/libfile).read_bytes())
                    table[renamed]=f'(lib (name "{renamed}")(type "KiCad")(uri "${{KIPRJMOD}}/{newfile}")(options "")(descr "Source {b}"))'
        def library_names(s):
            for (board,lib),renamed in names.items():
                if board==b: s=s.replace(f'"{lib}:',f'"{renamed}:')
            return s
        for block in blocks[b]:
            if block.startswith("(lib_symbols"):
                for symbol in children(block):
                    fixed=library_names(symbol)
                    libraries.setdefault(re.match(r'\(symbol "([^"]+)',fixed)[1],fixed)
        cuts=set()
        labels={anchors(s)[0]:re.match(r'\(label "([^"]+)',s)[1] for s in blocks[b] if s.startswith("(label ")}
        skip=set()
        for block in blocks[b]:
            if not block.startswith("(symbol "):
                continue
            ref=re.search(r'\(property "Reference" "([^"]+)',block)[1]
            x,y=anchors(block)[0]
            if ref in removed[b]:
                n=int(re.search(r'Conn_01x(\d+)_Pin',block)[1])
                cuts.update(point(x+5.08,y+2.54*(i-(n-1)//2)) for i in range(n))
                skip.add(block)
            if ref.startswith("#FLG"):
                point0=(x,y)
                endpoints=[p for w in blocks[b] if w.startswith("(wire ") and point0 in anchors(w) for p in anchors(w) if p!=point0]
                label=next((labels[p] for p in endpoints if p in labels),None)
                if label:
                    alias=aliases.get((b,label),label)
                    if alias in flag_nets:
                        cuts.add(point0)
                        skip.add(block)
                    else: flag_nets.add(alias)
        erased=set(cuts)
        for block in blocks[b]:
            if block.startswith("(wire ") and cuts.intersection(anchors(block)):
                erased.update(anchors(block))
                skip.add(block)
        for block in blocks[b]:
            kind=block[1:].split(None,1)[0]
            if block in skip or kind not in {"symbol","wire","label","text","no_connect","junction"}: continue
            if kind=="label" and anchors(block)[0] in erased: continue
            if kind=="label":
                block=re.sub(r'^(\(label ")([^"]+)',lambda m:m[1]+aliases.get((b,m[2]),m[2] if index==0 else f"{b}_{m[2]}"),block)
            if kind=="symbol":
                block=library_names(block)
                def refname(m):
                    x=m[2]
                    p=re.fullmatch(r'([A-Za-z#]+)(\d+)',x)
                    assert p,x
                    return m[1]+p[1]+str(int(p[2])+1000*index)
                block=re.sub(r'(\(property "Reference" "|\(reference ")([^"]+)',refname,block)
                block=re.sub(r'\(project "[^"]+"',f'(project "{name}"',block)
                block=re.sub(r'\(path "/[^"]+"',f'(path "/{root}"',block)
            dx,dy=((0,0),(0,279.4),(406.4,0))[index]
            block=coord.sub(lambda m:f'({m[1]} {float(m[2])+dx:.4f} {float(m[3])+dy:.4f}',block)
            final.append(block)
    target.mkdir(exist_ok=True)
    (target/(name+".kicad_sch")).write_text(f'(kicad_sch (version 20250114) (generator eeschema) (uuid "{root}") (paper "A1") (title_block (title "{name}"))\n(lib_symbols\n'+ "\n".join(libraries.values())+")\n"+"\n".join(final)+'\n(sheet_instances (path "/" (page "1"))))\n')
    (target/(name+".kicad_pro")).write_text("{}\n")

for name,active in (("dac_analog",["DAC","ANA"]),("digital_input",["IN","USB","SPD"])):
    build(name,active)
# A project library table is shared by both root sheets.
entries=[]
for path in target.glob("*_*.kicad_sym"):
    prefix, name=path.stem.split("_",1)
    if name=="Receiver": name="SPDIF"
    entries.append(f'(lib (name "{prefix}_{name}")(type "KiCad")(uri "${{KIPRJMOD}}/{path.name}")(options "")(descr ""))')
(target/"sym-lib-table").write_text("(sym_lib_table (version 7) "+"\n".join(entries)+")\n")
